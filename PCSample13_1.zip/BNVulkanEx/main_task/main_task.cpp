#include <../legencyUtil/util.hpp>
#include <assert.h>
#include <string.h>
#include <cstdlib>
#include ".././main_task/MyVulkanManager.h"
int sample_main()
{
	MyVulkanManager::doVulkan();
	return 0;
}
