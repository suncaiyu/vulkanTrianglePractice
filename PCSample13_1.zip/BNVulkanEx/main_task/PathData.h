#ifndef PathData_H
#define PathData_H
#define PathPre "G:/��Դ/Vulkan����ʵս���/Vulkan����ʵս���A20182950/��13�� ��ʵ��ѧ������ģ��/PCSample13_1/BNVulkanEx/"
#define VertShaderPath3D PathPre ## "shaders/commonTex.vert";
#define FragShaderPath3D PathPre ## "shaders/commonTex.frag";
#define VertShaderPath3DCube PathPre ## "shaders/cubemap.vert";
#define FragShaderPath3DCube PathPre ## "shaders/cubemap.frag";

#define TextureSkycubemap_back PathPre ## "texture/skycubemap_back.bntex"
#define TextureSkycubemap_down PathPre ## "texture/skycubemap_down.bntex"
#define TextureSkycubemap_front PathPre ## "texture/skycubemap_front.bntex"
#define TextureSkycubemap_left PathPre ## "texture/skycubemap_left.bntex"
#define TextureSkycubemap_right PathPre ## "texture/skycubemap_right.bntex"
#define TextureSkycubemap_up PathPre ## "texture/skycubemap_up.bntex"

#define TextureCubeLi PathPre ## "texture/cube.bntexcube"

#define Objch_tfPath PathPre ## "model/ch_t.obj"

#define TexturePath PathPre ## "texture/wall.bntex"


#endif
