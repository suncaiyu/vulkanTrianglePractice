#ifndef HELP_H
#define HELP_H
class MyData
{
  public:
	struct android_app* app;
};
#endif
