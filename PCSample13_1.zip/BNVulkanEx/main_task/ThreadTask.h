#ifndef VULKANEXBASE_THREADTASK_H
#define VULKANEXBASE_THREADTASK_H
class ThreadTask
{
public:
    ThreadTask();
    ~ThreadTask();
    void doTask();
};
#endif 
