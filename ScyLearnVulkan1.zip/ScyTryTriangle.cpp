#include "ScyTryTriangel.h"
#include "TriangleData.h"

using namespace std;

const std::vector<const char*> validationLayers = {
    "VK_LAYER_LUNARG_standard_validation"
};
const std::vector<const char*> deviceExtensions = {
    VK_KHR_SWAPCHAIN_EXTENSION_NAME
};
#ifdef NDEBUG
const bool enableValidationLayers = false;
#else
const bool enableValidationLayers = true;
#endif


ScyTryTriangle::ScyTryTriangle()
{
}

ScyTryTriangle::~ScyTryTriangle()
{

}
void ScyTryTriangle::InitWindow()
{
    glfwInit();
    glfwWindowHint(GLFW_CLIENT_API, GLFW_NO_API);
    window = glfwCreateWindow(800, 600, "ScyTryTriangle", nullptr, nullptr);
    screenWidth = 800;
    screenHeight = 600;
}
void ScyTryTriangle::InitInstance()
{
    /*����1����glfw*/
    //uint32_t extensionCount = 0;
    //const char** glfwExtensions;
    //glfwExtensions = glfwGetRequiredInstanceExtensions(&extensionCount);

    //std::vector<const char*> extensions(glfwExtensions, glfwExtensions + extensionCount);
    //for (int i = 0; i < extensionCount; i++) {
    //    cout << extensions[i]<<endl;
    //}
    /*���������ֶ�������Ҫ����չ*/
    std::vector<const char *> instanceExtensionNames;
    instanceExtensionNames.push_back(VK_KHR_SURFACE_EXTENSION_NAME);//�˴���ֲWindows�������
    instanceExtensionNames.push_back("VK_KHR_win32_surface");//�˴���ֲWindows��Ҫ��ȡVK_KHR_SURFACE_EXTENSION_NAME��չ
    VkApplicationInfo appInfo = {};
    appInfo.apiVersion = VK_MAKE_VERSION(0, 0, 0);
    appInfo.engineVersion = VK_MAKE_VERSION(0, 0, 0);
    appInfo.applicationVersion = 0.1;
    appInfo.pApplicationName = "ScyLearn";
    appInfo.sType = VK_STRUCTURE_TYPE_APPLICATION_INFO;

    VkInstanceCreateInfo createInfo = {};
    createInfo.sType = VK_STRUCTURE_TYPE_INSTANCE_CREATE_INFO;
    createInfo.pApplicationInfo = &appInfo;
    createInfo.enabledExtensionCount = instanceExtensionNames.size();;
    createInfo.ppEnabledExtensionNames = instanceExtensionNames.data();

    createInfo.pNext = nullptr;
    createInfo.flags = 0;
    VkResult flag = vkCreateInstance(&createInfo, nullptr, &instance);
    if (flag == 0) {
    }else{
        throw std::runtime_error("not create instance!");
    }
}

void ScyTryTriangle::InitVulkan()
{
    InitInstance();
    SelectAndInitDevice();
    CreateLogicalDevice();
    CreateCommandBuffer();
    CreateSwapChain();
    CreateDepthBuffer();
    Createrenderpass();  ///>��ʼ��Ⱦ
    CreateFramebuffer();
    CreateDrawableObject();
}

void ScyTryTriangle::CreateDrawableObject()
{
    TriangleData::genVertexData();//������ɫ�����ζ������ݺ���ɫ����
    triForDraw = new DrawableObjectCommonLight(TriangleData::vdata, TriangleData::dataByteCount, TriangleData::vCount, device, memoryroproperties);
}

void ScyTryTriangle::CreateFramebuffer()
{
    VkImageView attachment[2];
    attachment[1] = depthImageView;
    VkFramebufferCreateInfo fb_info = {};
    fb_info.attachmentCount = 2;
    fb_info.sType = VK_STRUCTURE_TYPE_FRAMEBUFFER_CREATE_INFO;
    fb_info.pNext = nullptr;
    fb_info.renderPass = renderPass;
    fb_info.pAttachments = attachment;
    fb_info.width = screenWidth;
    fb_info.height = screenHeight;
    fb_info.layers = 1;
    uint32_t i = 1;
    framebuffers = (VkFramebuffer *)malloc(swapChainImageCount * sizeof(VkFramebuffer));
    for (i = 0; i < swapChainImageCount; ++i) {
        attachment[0] = swapChainImageView[i];
        VkResult result = vkCreateFramebuffer(device, &fb_info, nullptr, &framebuffers[i]);
        assert(result == VK_SUCCESS);
        cout << "��������֡�ɹ�" << endl;
    }
}

void ScyTryTriangle::Createrenderpass()
{
    //�ź�������ṹ��
    VkSemaphoreCreateInfo imageAcquireSemaphoreCreateInfo;
    imageAcquireSemaphoreCreateInfo.sType = VK_STRUCTURE_TYPE_SEMAPHORE_CREATE_INFO;
    imageAcquireSemaphoreCreateInfo.pNext = nullptr;
    imageAcquireSemaphoreCreateInfo.flags = 0;
    VkResult result = vkCreateSemaphore(device, &imageAcquireSemaphoreCreateInfo, nullptr, &imageAcquiredSemaphore);
    assert(result == VK_SUCCESS);

    VkAttachmentDescription attachments[2];
    attachments[0].format = formats[0]; //>��ɫ�����ĸ�ʽ
    attachments[0].samples = VK_SAMPLE_COUNT_1_BIT;
    //����Ⱦͨ����ʼʱ ��ɫ����
    attachments[0].loadOp = VK_ATTACHMENT_LOAD_OP_CLEAR;
    // ����Ⱦͨ������ʱ  ��ɫ����
    attachments[0].storeOp = VK_ATTACHMENT_STORE_OP_STORE;
    //����Ⱦͨ����ʼʱ  ģ��
    attachments[0].stencilLoadOp = VK_ATTACHMENT_LOAD_OP_DONT_CARE;
    // ����Ⱦͨ������ʱ ģ�帽��
    attachments[0].stencilStoreOp = VK_ATTACHMENT_STORE_OP_DONT_CARE;
    attachments[0].initialLayout = VK_IMAGE_LAYOUT_UNDEFINED;
    attachments[0].finalLayout = VK_IMAGE_LAYOUT_PRESENT_SRC_KHR;
    attachments[0].flags = 0;
    attachments[1].format = depthFormat; //>����depthFormat�ĸ�ʽ
    attachments[1].samples = VK_SAMPLE_COUNT_1_BIT;
    attachments[1].loadOp = VK_ATTACHMENT_LOAD_OP_CLEAR;
    attachments[1].storeOp = VK_ATTACHMENT_STORE_OP_DONT_CARE;
    attachments[1].stencilLoadOp = VK_ATTACHMENT_LOAD_OP_DONT_CARE;
    attachments[1].stencilStoreOp = VK_ATTACHMENT_STORE_OP_DONT_CARE;
    attachments[1].initialLayout = VK_IMAGE_LAYOUT_UNDEFINED;
    attachments[1].finalLayout = VK_IMAGE_LAYOUT_DEPTH_STENCIL_ATTACHMENT_OPTIMAL;
    attachments[1].flags = 0;
    //��ɫ���ø���
    VkAttachmentReference color_reference = {};
    color_reference.attachment = 0;
    color_reference.layout = VK_IMAGE_LAYOUT_COLOR_ATTACHMENT_OPTIMAL;

    VkAttachmentReference depth_reference = {};
    depth_reference.attachment = 1;
    depth_reference.layout = VK_IMAGE_LAYOUT_DEPTH_ATTACHMENT_OPTIMAL;

    //subpass����ִ�ж�attachment�Ķ�д����
    VkSubpassDescription subpass = {}; //������Ⱦ��ͨ����������
    subpass.pipelineBindPoint = VK_PIPELINE_BIND_POINT_GRAPHICS; // ���ù��ߵİ󶨵�
    subpass.flags = 0;
    subpass.inputAttachmentCount = 0;
    subpass.pInputAttachments = NULL;
    subpass.colorAttachmentCount = 1;
    subpass.pColorAttachments = &color_reference;
    subpass.pResolveAttachments = nullptr;
    subpass.pDepthStencilAttachment = &depth_reference;
    subpass.preserveAttachmentCount = 0;
    subpass.pPreserveAttachments = nullptr;
    // ��Ⱦ��ͨ�������ṹ��
    VkRenderPassCreateInfo rp_info = {};
    rp_info.sType = VK_STRUCTURE_TYPE_RENDER_PASS_CREATE_INFO;
    rp_info.pNext = nullptr;
    rp_info.attachmentCount = 2;
    rp_info.pAttachments = attachments;
    rp_info.subpassCount = 1;
    rp_info.pSubpasses = &subpass;
    rp_info.dependencyCount = 0;
    rp_info.pDependencies = nullptr;
    result = vkCreateRenderPass(device, &rp_info, nullptr, &renderPass);
    assert(result == VK_SUCCESS);
    clear_values[0].color.float32[0] = 0.2f;
    clear_values[0].color.float32[1] = 0.2f;
    clear_values[0].color.float32[2] = 0.2f;
    clear_values[0].color.float32[3] = 0.2f;
    clear_values[1].depthStencil.depth = 1.0f;
    clear_values[1].depthStencil.stencil = 0;
    rp_begin.sType = VK_STRUCTURE_TYPE_RENDER_PASS_BEGIN_INFO;
    rp_begin.pNext = nullptr;
    rp_begin.renderPass = renderPass;
    rp_begin.renderArea.offset.x = 0;
    rp_begin.renderArea.offset.y = 0;
    rp_begin.renderArea.extent.height = screenHeight;
    rp_begin.renderArea.extent.width = screenWidth;
    rp_begin.clearValueCount = 2;
    rp_begin.pClearValues = clear_values;
}

bool memoryTypeFromProperties(VkPhysicalDeviceMemoryProperties& memoryProperties, uint32_t typeBits, VkFlags requirements_mask, uint32_t *typeIndex)
{
    //ѭ��ȷ���ڴ���������
    for (uint32_t i = 0; i < 32; i++)
    {
        //����Ӧ���ͱ���λΪ1
        if ((typeBits & 1) == 1)
        {
            //������������ƥ��
            if ((memoryProperties.memoryTypes[i].propertyFlags & requirements_mask) == requirements_mask)
            {
                *typeIndex = i;
                return true;
            }
        }
        typeBits >>= 1;
    }
    //û���ҵ��������������
    return false;
}

void ScyTryTriangle::CreateDepthBuffer()
{
    // ָ�����ͼ��ĸ�ʽ
    depthFormat = VK_FORMAT_D16_UNORM;
    // �������ͼ��ṹ��
    VkImageCreateInfo image_info = {};
    //��ȡ�����豸֧�ֵ�ͼ���ʽ�ľ���ϸ������
    vkGetPhysicalDeviceFormatProperties(physicalDevice, depthFormat, &depthFormatProps);
    if (depthFormatProps.linearTilingFeatures & VK_FORMAT_FEATURE_DEPTH_STENCIL_ATTACHMENT_BIT) {   //�Ƿ�֧��������Ƭ��֯��ʽ
        image_info.tiling = VK_IMAGE_TILING_LINEAR; //����������Ƭ��֯
        cout << "tillingΪVK_IMAGE_TILING_LINEAR" << endl;
    }
    else if (depthFormatProps.optimalTilingFeatures & VK_FORMAT_FEATURE_DEPTH_STENCIL_ATTACHMENT_BIT) {    //�Ƿ�֧��������Ƭ��֯
        image_info.tiling = VK_IMAGE_TILING_OPTIMAL;
        cout << "tillingΪVK_IMAGE_TILING_OPTIMAL" << endl;
    }
    else {
        cout << "��֧��VK_FORMAT_D16_UNORM" << endl;
    }
    image_info.sType = VK_STRUCTURE_TYPE_IMAGE_CREATE_INFO;
    image_info.pNext = nullptr;
    image_info.imageType = VK_IMAGE_TYPE_2D;
    image_info.format = depthFormat;

    image_info.extent.width = screenWidth;
    image_info.extent.height = screenHeight;
    image_info.extent.depth = 1;
    image_info.mipLevels = 1;
    image_info.arrayLayers = 1;
    image_info.samples = VK_SAMPLE_COUNT_1_BIT;
    image_info.initialLayout = VK_IMAGE_LAYOUT_UNDEFINED;
    image_info.usage = VK_IMAGE_USAGE_DEPTH_STENCIL_ATTACHMENT_BIT;
    image_info.queueFamilyIndexCount = 0;
    image_info.pQueueFamilyIndices = nullptr;
    image_info.sharingMode = VK_SHARING_MODE_EXCLUSIVE;
    image_info.flags = 0;
    // �ڴ������Ϣ�Ľṹ��
    VkMemoryAllocateInfo mem_alloc = {};
    mem_alloc.sType = VK_STRUCTURE_TYPE_MEMORY_ALLOCATE_INFO;
    mem_alloc.pNext = nullptr;
    mem_alloc.allocationSize = 0;
    mem_alloc.memoryTypeIndex = 0;

    // ���ͼ��view�Ľṹ��
    VkImageViewCreateInfo view_info = {};
    view_info.sType = VK_STRUCTURE_TYPE_IMAGE_VIEW_CREATE_INFO;
    view_info.pNext = nullptr;
    view_info.image = VK_NULL_HANDLE;
    view_info.format = depthFormat;
    view_info.components.a = VK_COMPONENT_SWIZZLE_A;
    view_info.components.r = VK_COMPONENT_SWIZZLE_R;
    view_info.components.g = VK_COMPONENT_SWIZZLE_G;
    view_info.components.b = VK_COMPONENT_SWIZZLE_B;

    view_info.subresourceRange.aspectMask = VK_IMAGE_ASPECT_DEPTH_BIT;
    view_info.subresourceRange.baseMipLevel = 0;
    view_info.subresourceRange.levelCount = 1;
    view_info.subresourceRange.baseArrayLayer = 0;
    view_info.subresourceRange.layerCount = 1;
    view_info.viewType = VK_IMAGE_VIEW_TYPE_2D;
    view_info.flags = 0;
    VkResult result = vkCreateImage(device, &image_info, nullptr, &depthImage);
    assert(result == VK_SUCCESS);
    VkMemoryRequirements mem_reqs;
    // ��ȡͼ���ڴ�
    vkGetImageMemoryRequirements(device, depthImage, &mem_reqs);
    mem_alloc.allocationSize = mem_reqs.size;
    VkFlags requirements_mask = 0; //��ȡ��Ҫ���ڴ���������
    // ��ȡ����Ҫ���ڴ����͵���������װ��һ������
    //memoryroproperties��֮ǰ���������豸�ǻ�ȡ���ڴ����ԣ�������
    bool flag = memoryTypeFromProperties(memoryroproperties, mem_reqs.memoryTypeBits, requirements_mask, &mem_alloc.memoryTypeIndex);
    assert(flag);
    cout << "ȷ���ڴ����ͳɹ�����������Ϊ��" << mem_alloc.memoryTypeIndex << endl;

    result = vkAllocateMemory(device, &mem_alloc, nullptr, &memDepth);
    assert(result == VK_SUCCESS);
    //��ͼ����ڴ�
    result = vkBindImageMemory(device, depthImage, memDepth, 0);
    assert(result == VK_SUCCESS);

    view_info.image = depthImage;
    result = vkCreateImageView(device, &view_info, nullptr, &depthImageView);
    assert(result == VK_SUCCESS);
}

void ScyTryTriangle::CreateSwapChain()
{
    CreateWindowSurface();
    //��ѯgpu�м�֧����ʾ����֧��ͼ�ι����Ķ��д�����
    //���ҵ�����֧����ʾ��
    VkBool32 *pSupportPresent = new VkBool32[queueFamilyCount];
    for (uint32_t i = 0; i < queueFamilyCount; ++i) {
        vkGetPhysicalDeviceSurfaceSupportKHR(physicalDevice, i, surface, &pSupportPresent[i]);
        string support = pSupportPresent[i] == 1 ? "֧��" : "��֧��";
        
        cout << "���дص�����" << i << " " << support.c_str() << "��ʾ" << endl;
    }

    queueGraphicsFamilyIndex = UINT32_MAX;
    queuePresentFamilyIndex = UINT32_MAX;
    for (uint32_t i = 0; i < queueFamilyCount; ++i) {
        if (queueFamilyproperties[i].queueFlags & VK_QUEUE_GRAPHICS_BIT) {
            //����ֻ�ҵ�һ������Ϊ֮ǰ�����߼��豸ɶ�ģ����д�Ҳ��ȡ�õ�һ��
            if (queueGraphicsFamilyIndex == UINT32_MAX) {
                queueGraphicsFamilyIndex = i;
            }
            if (pSupportPresent[i] == VK_TRUE) {
                //��֧�֣���֧�֣�ʡ��
                queueGraphicsFamilyIndex = i;
                queuePresentFamilyIndex = i;
                cout << "��֧�֣���֧�ֵ��Ƕ��дأ�" << i << endl;
                break;
            }
        }
    }
    if (queuePresentFamilyIndex == UINT32_MAX) {
        //����ͬʱ֧�֣��ֿ���
        for (uint32_t i = 0; i < queueFamilyCount; ++i) {
            if (pSupportPresent[i] == VK_TRUE) {
                queuePresentFamilyIndex = i;
                break;
            }
        }
    }
    delete[] pSupportPresent;
    if (queuePresentFamilyIndex == UINT32_MAX || queueGraphicsFamilyIndex == UINT32_MAX) {
        throw std::runtime_error("û���ҵ�֧��ͼ�ι������߳��ֹ����Ķ��д�!");
    }

    // ��ȡsurface֧�ֵ���ʾ��ʽ����Ϊswapchain��image�������ʾ��surface�ϣ���Ҫͬ��
    uint32_t formatCount;
    VkResult result = vkGetPhysicalDeviceSurfaceFormatsKHR(physicalDevice, surface, &formatCount, nullptr);
    cout << "֧����ʾ�ĸ�ʽ����Ϊ��" << formatCount << endl;
    VkSurfaceFormatKHR *surfaceFormat = new VkSurfaceFormatKHR[formatCount];
    formats.resize(formatCount);
    result = vkGetPhysicalDeviceSurfaceFormatsKHR(physicalDevice, surface, &formatCount, surfaceFormat);
    for (int i = 0; i < formatCount; ++i) {
        formats[i] = surfaceFormat[i].format;
        cout << "֧�ֵĵ�" << i << "����ʽΪ��" << formats[i] << endl;
    }
    if (formats.size() == 1 && formats[0] == VK_FORMAT_UNDEFINED) {
        formats[0] = VK_FORMAT_R8G8B8A8_UNORM;
    }
    delete[] surfaceFormat;

    //swapchain��image���û�����һЩsurface����Ϣ�����Ի�ȡsurface�ı�����������ʾģʽ
    result = vkGetPhysicalDeviceSurfaceCapabilitiesKHR(physicalDevice, surface, &surfaceCapabilityes);
    assert(result == VK_SUCCESS);
    uint32_t presentCount;
    result = vkGetPhysicalDeviceSurfacePresentModesKHR(physicalDevice, surface, &presentCount, nullptr);
    assert(result == VK_SUCCESS);
    cout << "surface֧�ֵ���ʾģʽ�����ǣ�" << presentCount << endl;
    presentMode.resize(presentCount);
    result = vkGetPhysicalDeviceSurfacePresentModesKHR(physicalDevice, surface, &presentCount, presentMode.data());
    for (int i = 0; i < presentCount; ++i) {
        cout << "��ʾģʽ��" << i << "���ı���ǣ�" << presentMode[i]<<"    ";
    }
    VkPresentModeKHR swapchainPresentMode = VK_PRESENT_MODE_FIFO_KHR;
    for (int i = 0; i < presentCount; ++i) {
        if (presentMode[i] == VK_PRESENT_MODE_MAILBOX_KHR) {
            swapchainPresentMode = presentMode[i];
            break;
        }
        if (presentMode[i] == VK_PRESENT_MODE_IMMEDIATE_KHR && swapchainPresentMode != VK_PRESENT_MODE_MAILBOX_KHR) {
            swapchainPresentMode = presentMode[i];
        }
    }

    //ȷ��swapchainͼ��ĳߴ�
    if (surfaceCapabilityes.currentExtent.width == 0xFFFFFFFF) {
        swapchainExtent.width = screenWidth;
        swapchainExtent.height = screenHeight;
        if (swapchainExtent.width < surfaceCapabilityes.minImageExtent.width) {
            swapchainExtent.width = surfaceCapabilityes.minImageExtent.width;
        }
        else if (swapchainExtent.width > surfaceCapabilityes.maxImageExtent.width) {
            swapchainExtent.width = surfaceCapabilityes.maxImageExtent.width;
        }

        if (swapchainExtent.height < surfaceCapabilityes.minImageExtent.height) {
            swapchainExtent.height = surfaceCapabilityes.minImageExtent.height;
        }
        else if (swapchainExtent.width > surfaceCapabilityes.maxImageExtent.width) {
            swapchainExtent.width = surfaceCapabilityes.maxImageExtent.width;
        }
        cout << "ʹ�õ��Լ����õĸ߶�:"<< swapchainExtent.height<<",���ȣ�"<<swapchainExtent.width <<endl;
    }
    else {
        swapchainExtent = surfaceCapabilityes.currentExtent;
        cout << "ʹ�õ�surface�����еĸ߶ȣ�"<< swapchainExtent .height<<",���ȣ�"<< swapchainExtent .width<<endl;
    }
    screenWidth = swapchainExtent.width;
    screenHeight = swapchainExtent.height;
    //�����Ľ�����������ͼ�������
    uint32_t desiredMinNumberOfSwapChainImages = surfaceCapabilityes.minImageCount + 1;
    if (surfaceCapabilityes.maxImageCount > 0 && (desiredMinNumberOfSwapChainImages > surfaceCapabilityes.maxImageCount)) {
        desiredMinNumberOfSwapChainImages = surfaceCapabilityes.maxImageCount;
    }
    VkSurfaceTransformFlagBitsKHR preTransform;
    //KHR����ı任��־������ͼ����ʾʱ����Ļ�������ת�����
    if (surfaceCapabilityes.currentTransform & VK_SURFACE_TRANSFORM_IDENTITY_BIT_KHR) {
        preTransform = VK_SURFACE_TRANSFORM_IDENTITY_BIT_KHR;
    }
    else {
        preTransform = surfaceCapabilityes.currentTransform;
    }

    // �����������������Ϣ����,��ʼ����swapchian
    VkSwapchainCreateInfoKHR swapchain_ci = {};
    swapchain_ci.sType = VK_STRUCTURE_TYPE_SWAPCHAIN_CREATE_INFO_KHR;
    swapchain_ci.pNext = nullptr;
    swapchain_ci.surface = surface;
    swapchain_ci.minImageCount = desiredMinNumberOfSwapChainImages;
    swapchain_ci.imageFormat = formats[0];
    swapchain_ci.imageExtent.width = swapchainExtent.width;
    swapchain_ci.imageExtent.height = swapchainExtent.height;
    swapchain_ci.preTransform = preTransform;
    swapchain_ci.compositeAlpha = VK_COMPOSITE_ALPHA_OPAQUE_BIT_KHR;
    swapchain_ci.imageArrayLayers = 1;
    swapchain_ci.presentMode = swapchainPresentMode;
    swapchain_ci.oldSwapchain = VK_NULL_HANDLE;
    swapchain_ci.clipped = true;
    swapchain_ci.imageColorSpace = VK_COLORSPACE_SRGB_NONLINEAR_KHR;
    swapchain_ci.imageSharingMode = VK_SHARING_MODE_EXCLUSIVE;
    swapchain_ci.imageUsage = VK_IMAGE_USAGE_COLOR_ATTACHMENT_BIT;
    swapchain_ci.queueFamilyIndexCount = 1;
    uint32_t queueFamilyIndices[] = { queueGraphicsFamilyIndex};
    swapchain_ci.pQueueFamilyIndices = queueFamilyIndices;
    // ���ǰ���ҵõ���֧��ͼ�ι����ͳ��ֹ����Ķ��дز�һ��������һ��
    if (queueGraphicsFamilyIndex != queuePresentFamilyIndex) {
        swapchain_ci.imageSharingMode = VK_SHARING_MODE_CONCURRENT;
        swapchain_ci.queueFamilyIndexCount = 2;
        uint32_t queueFamilyIndices[2] = {queueGraphicsFamilyIndex, queuePresentFamilyIndex};
        swapchain_ci.pQueueFamilyIndices = queueFamilyIndices;
    }

    result  = vkCreateSwapchainKHR(device, &swapchain_ci,nullptr, &swapChain);
    assert(result == VK_SUCCESS);

    //Ϊ�������е�ÿһ��ͼ������view

    result = vkGetSwapchainImagesKHR(device, swapChain, &swapChainImageCount, nullptr);
    assert(result == VK_SUCCESS);
    cout << "��������ͼ�������ǣ�" << swapChainImageCount << endl;
    swapChainImage.resize(swapChainImageCount);
    result = vkGetSwapchainImagesKHR(device, swapChain, &swapChainImageCount, swapChainImage.data());
    assert(result == VK_SUCCESS);
    swapChainImageView.resize(swapChainImageCount);
    //����swapChainImageCount��view����
    for (int i = 0; i < swapChainImageCount; ++i) {
        VkImageViewCreateInfo color_image_view = {};
        color_image_view.sType = VK_STRUCTURE_TYPE_IMAGE_VIEW_CREATE_INFO;
        color_image_view.pNext = nullptr;
        color_image_view.flags = 0;
        color_image_view.image = swapChainImage[i];
        color_image_view.viewType = VK_IMAGE_VIEW_TYPE_2D;
        color_image_view.format = formats[0];
        color_image_view.components.r = VK_COMPONENT_SWIZZLE_R;
        color_image_view.components.g = VK_COMPONENT_SWIZZLE_G;
        color_image_view.components.b = VK_COMPONENT_SWIZZLE_B;
        color_image_view.components.a = VK_COMPONENT_SWIZZLE_A;
        color_image_view.subresourceRange.aspectMask = VK_IMAGE_ASPECT_COLOR_BIT;
        color_image_view.subresourceRange.baseMipLevel = 0;
        color_image_view.subresourceRange.levelCount = 1;
        color_image_view.subresourceRange.baseArrayLayer = 0;
        color_image_view.subresourceRange.layerCount = 1;
        result = vkCreateImageView(device, &color_image_view, nullptr, &swapChainImageView[i]);
        assert(result == VK_SUCCESS);
    }
}

void ScyTryTriangle::CreateCommandBuffer()
{
    //�ȴ��أ��ڷ�����,һ�����д�Ҫ��һ����
    VkCommandPoolCreateInfo cmdpoolInfo = {};
    cmdpoolInfo.sType = VK_STRUCTURE_TYPE_COMMAND_POOL_CREATE_INFO;
    cmdpoolInfo.pNext = nullptr;
    cmdpoolInfo.queueFamilyIndex = queueGraphicsFamilyIndex;
    cmdpoolInfo.flags = VK_COMMAND_POOL_CREATE_RESET_COMMAND_BUFFER_BIT;
    VkResult result = vkCreateCommandPool(device, &cmdpoolInfo, nullptr,&cmdPool);
    if (result == VK_SUCCESS) {
        cout << "��������سɹ�" << endl;
    }
    else {
        cout << "���������ʧ��~~~~~" << endl;
    }

    //������
    VkCommandBufferAllocateInfo cmdBAI = {};
    cmdBAI.sType = VK_STRUCTURE_TYPE_COMMAND_BUFFER_ALLOCATE_INFO;
    cmdBAI.pNext = nullptr;
    cmdBAI.commandPool = cmdPool;
    cmdBAI.level = VK_COMMAND_BUFFER_LEVEL_PRIMARY;
    cmdBAI.commandBufferCount = 1;
    result = vkAllocateCommandBuffers(device, &cmdBAI, &cmdBuffer);
    if (result == VK_SUCCESS) {
        cout << "���仺��ɹ�" << endl;
    }
    else {
        cout << "���仺��ʧ��~~~~~" << endl;
    }

    cmd_buf_info.sType = VK_STRUCTURE_TYPE_COMMAND_BUFFER_BEGIN_INFO;//�����ṹ������
    cmd_buf_info.pNext = NULL;//�Զ������ݵ�ָ��
    cmd_buf_info.flags = 0;//����ʹ�ñ�־
    cmd_buf_info.pInheritanceInfo = NULL;//�����̳���Ϣ
    cmd_bufs[0] = cmdBuffer;//Ҫ�ύ������ִ�е����������

    VkPipelineStageFlags* pipe_stage_flags = new VkPipelineStageFlags();//Ŀ����߽׶�
    *pipe_stage_flags = VK_PIPELINE_STAGE_COLOR_ATTACHMENT_OUTPUT_BIT;
    submit_info[0].pNext = NULL;//�Զ������ݵ�ָ��
    submit_info[0].sType = VK_STRUCTURE_TYPE_SUBMIT_INFO;//�����ṹ������
    submit_info[0].pWaitDstStageMask = pipe_stage_flags;//����Ŀ����߽׶�
    submit_info[0].commandBufferCount = 1;//���������
    submit_info[0].pCommandBuffers = cmd_bufs;//�ύ�����������
    submit_info[0].signalSemaphoreCount = 0;//�ź�������
    submit_info[0].pSignalSemaphores = NULL;//�ź�������
}

void ScyTryTriangle::CreateLogicalDevice()
{
    // �ҳ������豸�еĶ��м��������
    vkGetPhysicalDeviceQueueFamilyProperties(physicalDevice, &queueFamilyCount, nullptr);
    queueFamilyproperties.resize(queueFamilyCount);
    vkGetPhysicalDeviceQueueFamilyProperties(physicalDevice, &queueFamilyCount, queueFamilyproperties.data());
    // ������Ϣ�ṹ�壬�����߼��豸��Ҫ�����Ǹ�����
    VkDeviceQueueCreateInfo queueInfo = {};
    bool found = false;
    for (uint32_t i = 0; i < queueFamilyCount; ++i) {
        if (queueFamilyproperties[i].queueFlags & VK_QUEUE_GRAPHICS_BIT) {
            queueInfo.queueFamilyIndex = i;
            queueGraphicsFamilyIndex = i;
            found = true;
            cout << "֧��Graphics�����Ķ��д������� �� " << i << endl;
            cout << "������д���ʵ��ӵ�еĶ��и����ǣ�" << queueFamilyproperties[i].queueCount << endl;
            break;
        }
    }
    // ������е����ȼ���0 - 1������ֻ��һ��������ν
    float queuePriorities[1] = { 0.0 };
    queueInfo.sType = VK_STRUCTURE_TYPE_DEVICE_QUEUE_CREATE_INFO;
    queueInfo.pNext = nullptr;
    queueInfo.queueCount = 1;
    queueInfo.pQueuePriorities = queuePriorities;

    // �豸��չ
    //vkEnumerateDeviceExtensionProperties(physicalDevice, nullptr, &deviceExtensionCount, nullptr);
    //deviceExtensionPropertities.resize(deviceExtensionCount);
    //vkEnumerateDeviceExtensionProperties(physicalDevice, nullptr, &deviceExtensionCount, deviceExtensionPropertities.data());
    //vector<const char*> deviceExtensionName;
    //for (VkExtensionProperties vep : deviceExtensionPropertities) {
    //    cout << vep.extensionName << endl;
    //    deviceExtensionName.push_back(vep.extensionName);
    //}
    vector<const char *>deviceExtensionName;
    deviceExtensionName.push_back(VK_KHR_SWAPCHAIN_EXTENSION_NAME);//����������չ
    deviceExtensionCount = deviceExtensionName.size();
    // �����߼��豸�Ľṹ��
    VkDeviceCreateInfo deviceInfo = {};
    deviceInfo.sType = VK_STRUCTURE_TYPE_DEVICE_CREATE_INFO;
    deviceInfo.enabledExtensionCount = deviceExtensionCount;
    deviceInfo.ppEnabledExtensionNames = deviceExtensionName.data();
    deviceInfo.enabledLayerCount = 0;
    deviceInfo.ppEnabledLayerNames = nullptr;
    deviceInfo.pEnabledFeatures = nullptr;
    deviceInfo.pNext = nullptr;
    deviceInfo.pQueueCreateInfos = &queueInfo;
    deviceInfo.queueCreateInfoCount = 1;
    VkResult result = vkCreateDevice(physicalDevice, &deviceInfo, nullptr, &device);
    if (result == VK_SUCCESS) {
        cout << "�����߼��豸�ɹ�"<<endl;
    }
    else {
        cout << "�����߼��豸ʧ��~~~~~" << endl;
    }
    //��ȡ���д��е�һ������
    vkGetDeviceQueue(device, queueGraphicsFamilyIndex, 0, &queueGraphics);
}

void ScyTryTriangle::SelectAndInitDevice()
{
    uint32_t gpuCount = 0;
    VkResult result = vkEnumeratePhysicalDevices(instance, &gpuCount, nullptr);

    if (result == VK_ERROR_INITIALIZATION_FAILED) {
        throw std::runtime_error("Cannot find a compatible Vulkan device or driver. Try updating your video driver to a more recent version and make sure your video card supports Vulkan.");
        return;
    }

    if (gpuCount == 0) {
        throw std::runtime_error("Couldn't enumerate physical devices! Make sure your drivers are up to date and that you are not pending a reboot.");
        return;
    }

    cout << "Found %d device(s) : " << gpuCount << endl;

    std::vector<VkPhysicalDevice> physicalDevices(gpuCount);
    vkEnumeratePhysicalDevices(instance, &gpuCount, physicalDevices.data());
    // һ����˵��һ̨�豸��һ��gpu��ѡ���һ��
    physicalDevice = physicalDevices[0];
    // ��ȡ�ڴ����ԣ�����
    vkGetPhysicalDeviceMemoryProperties(physicalDevices[0], &memoryroproperties);
}

void ScyTryTriangle::mainLoop()
{
    while (!glfwWindowShouldClose(window)) {
        glfwPollEvents();
    }
}

void ScyTryTriangle::CreateWindowSurface() {
    //����KHR����
    int i = glfwCreateWindowSurface(instance, window, nullptr, &surface);
    if (glfwCreateWindowSurface(instance, window, nullptr, &surface) != VK_SUCCESS) {
        throw std::runtime_error("failed to create window surface!");
    }
}
void ScyTryTriangle::cleanup()
{
    vkDestroyInstance(instance, nullptr);
    glfwDestroyWindow(window);
    glfwTerminate();
}
//int main()
//{
//    ScyTryTriangle scy;
//    try {
//        scy.run();
//    }
//    catch(const std::exception& e){
//        cerr << e.what() << endl;
//        return EXIT_FAILURE;
//    }
//    return 0;
//}

DrawableObjectCommonLight::DrawableObjectCommonLight(float *vdataIn, int dataByteCount, int vCountIn, VkDevice &device, VkPhysicalDeviceMemoryProperties &memoryroperties)
{
    this->devicePointer = &device;
    this->vdata = vdataIn;
    this->vCount = vCountIn;
    // �������崴���ṹ��
    VkBufferCreateInfo buf_info = {};
    buf_info.sType = VK_STRUCTURE_TYPE_BUFFER_CREATE_INFO;
    buf_info.pNext = nullptr;
    buf_info.usage = VK_BUFFER_USAGE_VERTEX_BUFFER_BIT;
    buf_info.size = dataByteCount;
    buf_info.queueFamilyIndexCount = 0;
    buf_info.pQueueFamilyIndices = nullptr;
    buf_info.sharingMode = VK_SHARING_MODE_EXCLUSIVE;
    buf_info.flags = 0;
    VkResult result = vkCreateBuffer(device, &buf_info, nullptr, &vertexDatabuf);
    assert(result == VK_SUCCESS);
    VkMemoryRequirements memreqs;
    vkGetBufferMemoryRequirements(device, vertexDatabuf, &memreqs);
    assert(dataByteCount <= memreqs.size);
    VkMemoryAllocateInfo alloc_info = {};
    alloc_info.sType = VK_STRUCTURE_TYPE_MEMORY_ALLOCATE_INFO;//�ṹ������
    alloc_info.pNext = NULL;//�Զ������ݵ�ָ��
    alloc_info.memoryTypeIndex = 0;//�ڴ���������
    alloc_info.allocationSize = memreqs.size;//�ڴ����ֽ���

    VkFlags requirements_mask = VK_MEMORY_PROPERTY_HOST_VISIBLE_BIT | VK_MEMORY_PROPERTY_HOST_COHERENT_BIT;
    bool flag = memoryTypeFromProperties(memoryroperties, memreqs.memoryTypeBits, requirements_mask, &alloc_info.memoryTypeIndex);
    if (flag) {
        cout << "ȷ���ڴ�ɹ��� " << "��������Ϊ  " << alloc_info.memoryTypeIndex << endl;
    }
    else {
        cout << "ȷ���ڴ�����ʧ��" << endl;
    }

    result = vkAllocateMemory(device, &alloc_info, nullptr, &vertexDataMem);
    assert(result == VK_SUCCESS);
    uint8_t *pData;
    result = vkMapMemory(device, vertexDataMem, 0, memreqs.size, 0, (void **)&pData);
    assert(result == VK_SUCCESS);
    memcpy(pData, vdata, dataByteCount);
    vkUnmapMemory(device, vertexDataMem);
    vkBindBufferMemory(device, vertexDatabuf, vertexDataMem, 0);
    vertexDataBufferInfo.buffer = vertexDatabuf; 
    vertexDataBufferInfo.offset = 0;
    vertexDataBufferInfo.range = memreqs.size;
}